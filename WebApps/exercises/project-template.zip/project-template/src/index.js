import React from 'react';
import ReactDOM from 'react-dom';

ReactDOM.render(null, document.getElementById('root'));
